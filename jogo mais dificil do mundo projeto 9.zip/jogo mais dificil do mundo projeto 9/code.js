var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["848314f8-d7dc-4755-a4a1-3782173096b1","26b80e63-bc0f-408d-b288-be2282aebd4e","dfc53be7-786c-4305-b8eb-81fa595e9903","47fade86-5bd1-4789-87af-896fb1433a7b","043deebf-64b8-4795-be8d-db5055414f2f","c26b6449-0b6c-4483-8486-107c0091c26e","3221caad-ae37-4eec-92a8-56bae4769e66","c4e310e0-8174-4127-a46e-0cbcc94b488b","d168edec-f527-449a-9f12-50a3e0b2c365","d2dab25e-321d-4a5a-b5ac-8e45fada0110","e3b9e7eb-4b32-482f-8e01-655edcb1129d","7e179d62-eb0a-44a6-91ba-5a5c6411cb50","f8e52644-2116-482b-a5f1-7b7d492b69fe","668f943e-c019-40c9-be9a-380cb113d76a"],"propsByKey":{"848314f8-d7dc-4755-a4a1-3782173096b1":{"name":"hero","sourceUrl":null,"frameSize":{"x":30,"y":30},"frameCount":1,"looping":true,"frameDelay":12,"version":"SQRh5l1uGm8okRjqtFS96PnSRiiAoE9M","categories":["sports"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":30,"y":30},"rootRelativePath":"assets/848314f8-d7dc-4755-a4a1-3782173096b1.png"},"26b80e63-bc0f-408d-b288-be2282aebd4e":{"name":"enemy1","sourceUrl":null,"frameSize":{"x":35,"y":50},"frameCount":1,"looping":true,"frameDelay":12,"version":"_kdjf6Ny4oYILbx1p8y422VIxtSvCy5I","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":35,"y":50},"rootRelativePath":"assets/26b80e63-bc0f-408d-b288-be2282aebd4e.png"},"dfc53be7-786c-4305-b8eb-81fa595e9903":{"name":"enemy","sourceUrl":"assets/api/v1/animation-library/gamelab/xasculQGiYxBV79ltD_0E79ZRIexdPdZ/category_food/american_hamburger.png","frameSize":{"x":320,"y":254},"frameCount":1,"looping":true,"frameDelay":2,"version":"xasculQGiYxBV79ltD_0E79ZRIexdPdZ","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":320,"y":254},"rootRelativePath":"assets/api/v1/animation-library/gamelab/xasculQGiYxBV79ltD_0E79ZRIexdPdZ/category_food/american_hamburger.png"},"47fade86-5bd1-4789-87af-896fb1433a7b":{"name":"enemy2","sourceUrl":"assets/api/v1/animation-library/gamelab/dVaFR7XFVlGQX4d.e71iiKWvnLhMbaxG/category_food/american_pastrami.png","frameSize":{"x":355,"y":241},"frameCount":1,"looping":true,"frameDelay":2,"version":"dVaFR7XFVlGQX4d.e71iiKWvnLhMbaxG","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":355,"y":241},"rootRelativePath":"assets/api/v1/animation-library/gamelab/dVaFR7XFVlGQX4d.e71iiKWvnLhMbaxG/category_food/american_pastrami.png"},"043deebf-64b8-4795-be8d-db5055414f2f":{"name":"enemy3","sourceUrl":"assets/api/v1/animation-library/gamelab/YSis4_lex43su6FLaL__bhoag4eHAl8D/category_food/american_bbqribs.png","frameSize":{"x":388,"y":388},"frameCount":1,"looping":true,"frameDelay":2,"version":"YSis4_lex43su6FLaL__bhoag4eHAl8D","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":388,"y":388},"rootRelativePath":"assets/api/v1/animation-library/gamelab/YSis4_lex43su6FLaL__bhoag4eHAl8D/category_food/american_bbqribs.png"},"c26b6449-0b6c-4483-8486-107c0091c26e":{"name":"hero1","sourceUrl":"assets/api/v1/animation-library/gamelab/loycQXdICpzI4PfXITdIndG9GcVBmRdK/category_faces/kidportrait_01.png","frameSize":{"x":264,"y":368},"frameCount":1,"looping":true,"frameDelay":2,"version":"loycQXdICpzI4PfXITdIndG9GcVBmRdK","categories":["faces"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":264,"y":368},"rootRelativePath":"assets/api/v1/animation-library/gamelab/loycQXdICpzI4PfXITdIndG9GcVBmRdK/category_faces/kidportrait_01.png"},"3221caad-ae37-4eec-92a8-56bae4769e66":{"name":"b","sourceUrl":"assets/api/v1/animation-library/gamelab/IJemJVUh3J1gcGlCdIJ8obCWhXAqxbUT/category_backgrounds/kitchen.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"IJemJVUh3J1gcGlCdIJ8obCWhXAqxbUT","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/IJemJVUh3J1gcGlCdIJ8obCWhXAqxbUT/category_backgrounds/kitchen.png"},"c4e310e0-8174-4127-a46e-0cbcc94b488b":{"name":"dream","sourceUrl":null,"frameSize":{"x":386,"y":268},"frameCount":1,"looping":true,"frameDelay":12,"version":"1KJ0NeYpdDQQEFcJgEuS1eU8l0Sxeccl","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":386,"y":268},"rootRelativePath":"assets/c4e310e0-8174-4127-a46e-0cbcc94b488b.png"},"d168edec-f527-449a-9f12-50a3e0b2c365":{"name":"sports_swimming_1","sourceUrl":"assets/api/v1/animation-library/gamelab/GuwVa7Xm79dWHBHBuVdL68E1T4DEVos_/category_backgrounds/sports_swimming.png","frameSize":{"x":400,"y":396},"frameCount":1,"looping":true,"frameDelay":2,"version":"GuwVa7Xm79dWHBHBuVdL68E1T4DEVos_","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":396},"rootRelativePath":"assets/api/v1/animation-library/gamelab/GuwVa7Xm79dWHBHBuVdL68E1T4DEVos_/category_backgrounds/sports_swimming.png"},"d2dab25e-321d-4a5a-b5ac-8e45fada0110":{"name":"basketball_1","sourceUrl":null,"frameSize":{"x":393,"y":394},"frameCount":1,"looping":true,"frameDelay":12,"version":".deS0ZUvR.kdEkaopJKM7rwYJjrN2YHq","categories":["sports"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":393,"y":394},"rootRelativePath":"assets/d2dab25e-321d-4a5a-b5ac-8e45fada0110.png"},"e3b9e7eb-4b32-482f-8e01-655edcb1129d":{"name":"crocodile_1","sourceUrl":"assets/api/v1/animation-library/gamelab/.OgILExIWH7zPE7eYiSHTuP5MvAT96YL/category_animals/crocodile.png","frameSize":{"x":390,"y":150},"frameCount":1,"looping":true,"frameDelay":2,"version":".OgILExIWH7zPE7eYiSHTuP5MvAT96YL","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":390,"y":150},"rootRelativePath":"assets/api/v1/animation-library/gamelab/.OgILExIWH7zPE7eYiSHTuP5MvAT96YL/category_animals/crocodile.png"},"7e179d62-eb0a-44a6-91ba-5a5c6411cb50":{"name":"nadador1 ","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"NXaJEIjrVjnRqfdZ3wkMjw9k_zF5t_wi","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/7e179d62-eb0a-44a6-91ba-5a5c6411cb50.png"},"f8e52644-2116-482b-a5f1-7b7d492b69fe":{"name":"animation_1","sourceUrl":"assets/api/v1/animation-library/mUlvnlbeZ5GHYr_Lb4NIuMwPs7kGxHWz/category_backgrounds/blank.png","frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":4,"version":"mUlvnlbeZ5GHYr_Lb4NIuMwPs7kGxHWz","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/api/v1/animation-library/mUlvnlbeZ5GHYr_Lb4NIuMwPs7kGxHWz/category_backgrounds/blank.png"},"668f943e-c019-40c9-be9a-380cb113d76a":{"name":"robot_27_1","sourceUrl":null,"frameSize":{"x":369,"y":389},"frameCount":1,"looping":true,"frameDelay":12,"version":"_7VcYUUhVROoZGdX2lIKXCmcUlJBnLPb","categories":["robots"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":369,"y":389},"rootRelativePath":"assets/668f943e-c019-40c9-be9a-380cb113d76a.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var fundo=createSprite(200,200)
fundo.setAnimation("sports_swimming_1")

var prince =
createSprite(390,90,10,10)
prince.setAnimation("hero")
prince.scale=1 

var nadador1=
createSprite(69,310,10,10)
nadador1.setAnimation("enemy1");
nadador1.scale= 3  

var nadador2=
createSprite(129,310,10,10)
nadador2.setAnimation("enemy1")
nadador2.scale= 3 

var nadador3=
createSprite(189,310,10,10)
nadador3.setAnimation("enemy1")
nadador3.scale= 3 

var nadador4=
createSprite(259,310,10,10)
nadador4.setAnimation("enemy1")
nadador4.scale= 3 

var nadador5=
createSprite(319,310,10,10)
nadador5.setAnimation("enemy1")
nadador5.scale= 3

var final=
createSprite(2,200,30,300)

nadador1.setVelocity(0,-10);
nadador2.setVelocity(0,15);
nadador3.setVelocity(0,-20);
nadador4.setVelocity(0,-25);
nadador5.setVelocity(0,20);

var death = 0;
var goal = 0;
function draw() {
  
  createEdgeSprites()

nadador1.bounceOff(edges)
nadador2.bounceOff(edges)
nadador3.bounceOff(edges)
nadador4.bounceOff(edges)
nadador5.bounceOff(edges)

if (keyDown("UP_ARROW")){
  prince.y=prince.y-4
}

if(keyDown(DOWN_ARROW)){
  prince.y=prince.y+4
}

if(keyDown(LEFT_ARROW)){
  prince.x=prince.x-4
}

if(keyDown(RIGHT_ARROW)){
  prince.x=prince.x+4
}

if(prince.isTouching(nadador1)|| prince.isTouching(nadador2)|| prince.isTouching(nadador3)|| prince.isTouching(nadador4)|| prince.isTouching(nadador5)){
  prince.x=220
  prince.y=365
  death= death+1
}

if(prince.isTouching(final)){
  hero.x=220
  prince.y=365
  prince=goal+1
}
textSize(20)
  fill("blue")
  text("Objetivos:"+goal,340,370);
  

textSize(20)
  fill("blue")
  text("mortes:"+death,25,310);



drawSprites()
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
